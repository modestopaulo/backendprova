import express from 'express';
import userController from '../controllers/userController.js';

const router = express.Router();

// Rota para registro de usuário
router.post('/register', userController.register);
router.put('/register', userController.register);
export default router;